package com.example.ririaplikasi;


import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class SectionsPagerAdapter extends FragmentStateAdapter {
    //set explicit jumlah fragmen
    private static final int JUMLAH_FRAGMENT = 2;


    @NonNull
    @Override
    public Fragment createFragment(int position) {

        switch (position){
            case 0:
                Tab1 tab1 = new Tab1();
                return tab1;
            case 1:
                Tab2 tab2 = new Tab2();
                return tab2;
            //TODO 1b :Tambahkan tab baru untuk melengkapi Menu Penerbangan Internasional
        }


        return new Tab1();
    }

    @Override
    public int getItemCount() {
        return JUMLAH_FRAGMENT;
    }

    public SectionsPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }
}
